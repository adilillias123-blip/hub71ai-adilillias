import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {seeds} from '../lib/rules.ts';
import {rankProgrammes,programmeDraft,programmes} from '../lib/programmes.ts';
const top=(s,m)=>rankProgrammes(s,m).filter(p=>p.priorityEligible).slice(0,3);
assert.equal(top(seeds[0])[0].id,'sandbox');
assert.equal(top(seeds[1])[0].id,'ai');
assert.equal(top(seeds.find(s=>s.id==='reefgrid'))[0].id,'climate');
assert.equal(top(seeds.find(s=>s.id==='ledgerharbor'))[0].id,'digital');
assert.equal(top(seeds[0],'validate')[0].id,'initiate');
for(const s of seeds){const priority=top(s);assert.equal(priority.length,3);assert.equal(new Set(priority.map(p=>p.id)).size,3);assert.ok(priority.every(p=>!p.closed&&!p.restricted));const rows=await readFile(new URL(`../public/samples/${s.id}-vault.csv`,import.meta.url),'utf8');assert.ok(rows.includes(`name,${s.name}`));}
const india=rankProgrammes(seeds.find(s=>s.id==='reefgrid')).find(p=>p.id==='india');assert.ok(india.score>50);
const draft=programmeDraft(seeds[0],'catalyst');assert.ok(draft.includes('The Catalyst'));assert.ok(draft.includes('Masdar City'));assert.ok(draft.includes('PayLogic'));assert.throws(()=>programmeDraft(seeds[0],'unknown'));
assert.equal(new Set(programmes.map(p=>p.id)).size,programmes.length);
console.log('Passed: sector-specific priorities, milestone reranking, restrictions, programme drafts and eight downloadable vaults.');
