import assert from 'node:assert/strict';
import {blueprint,seeds,draft} from '../lib/rules.ts';
for(const [i,score] of [87,59,83].entries())assert.equal(blueprint(seeds[i]).score,score);
const p=blueprint(seeds[0]);assert.equal(p.costs.setup,17.7);assert.ok(Math.abs(p.costs.adBurn-54.7)<1e-9);assert.ok(Math.abs(p.costs.homeBurn-75.6)<1e-9);assert.equal(p.match,95);assert.equal(p.visa,true);assert.equal(p.ventureAverage,82.5);
const n=blueprint(seeds[1]);assert.equal(n.visa,false);assert.equal(n.match,84);
const zero=blueprint({...seeds[0],raised:0,arr:0});assert.equal(zero.costs.adRunway,0);assert.equal(zero.costs.homeRunway,0);
const huge=blueprint({...seeds[0],raised:1000,arr:100000,team:1000});assert.ok(huge.score<=100);assert.ok(huge.venture.every(x=>x.value<=97));
console.log('Passed: seed scores, criteria match, costs, runway bounds and venture caps.');

for(const s of seeds.filter(s=>s.raised===0)){const b=blueprint(s);assert.equal(b.costs.adRunway,0);assert.equal(b.costs.homeRunway,0);assert.equal(b.costs.gained,0);assert.ok(b.costs.setup>0);for(const g of b.facets)for(const e of g.entries){const text=draft(s,'pilot',e.name,e.role);assert.ok(text.includes(e.name));assert.ok(text.includes('not raised external capital'));if(g.name==='Investors')assert.ok(text.includes('investment focus'));if(g.name==='API partners')assert.ok(text.includes('API'));if(g.name==='Developers')assert.ok(text.includes('technical delivery'));}}
console.log('Passed: unfunded landing budgets, zero baseline runway and outreach adapted to all four party categories.');
