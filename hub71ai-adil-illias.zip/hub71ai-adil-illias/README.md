# Launchpad AD

A founder move-planning and deal-flow showcase built from the Launchpad AD PRD v2.0. Refined around moving to Abu Dhabi, settling in and building a future with the startup team.

## Included

- Founder vault upload (CSV fully operational; PDF and PNG use OpenAI when configured).
- Eight downloadable synthetic datasets: PayLogic, NeuroDesk, AgriSense, ReefGrid, VitaBridge, LedgerHarbor, NurtureLoop and ClearDrop. The last two are unfunded founders planning a first raise in Abu Dhabi.
- Shared Set Up, Costs, Pilot and Connect blueprints with versioned, explainable rules.
- 18 selectable ecosystem routes with three priorities, provider-specific intake drafts and official references.
- Reach out / Connect actions for every Pilot party and Connect person, with editable, saved outreach and a user-entered verified email address to open an email-app draft. Nothing is sent automatically.
- Unfunded startups are included: baseline runway remains zero while landing and monthly operating budgets stay visible.
- Persisted startup records and conditional Fast-Track decisions in Cloudflare D1.
- Administrator pipeline, evidence breakdown, draft generation and four-second status polling.
- Three-question fallback, light and dark themes, responsive layouts and accessible primitives.

## Run and verify

Use the project scripts for development and build. The managed environment uses supervised Sites preview.

- `node --experimental-strip-types tests/rules.test.mjs` verifies PRD formula behavior.
- `node tests/integration.mjs` checks the production Worker with an isolated local test database, including uploads, authentication, access isolation, persistence, drafts and server rendering. Run after building.
- `node node_modules/typescript/bin/tsc --noEmit` checks types.

## AI configuration

Set server-side `OPENAI_API_KEY` and optionally `OPENAI_MODEL`. PDF and image extraction uses the Responses API with strict structured output, per-file parallel processing, per-field source validation, conflict checks and an 18-second timeout. Uploaded documents are processed in memory and not saved. `store: false` is sent to the API; provider data processing policies still apply. The AI path must be tested with synthetic documents after credentials are configured.

Drafts are deterministic templates based on extracted fields and contain the required review banner. Partner and contact matches use the PRD’s explicitly labeled placeholder heuristics, not live embedding matching. They require a verified directory before production use.

## Showcase access and scope

Both founder and administrator flows support anonymous use inside the application. An anonymous visitor receives an HttpOnly session cookie for an isolated, database-backed showcase workspace. Authenticated platform users retain their existing workspace records. Admin actions are intentionally unrestricted within each visitor's demo. No real programme invitation is issued.

The owner requested public hosting, but the current workspace refused the access change with `sites_publish_disabled`: internet publishing is not enabled. The published Site therefore retains its platform access gate until a workspace administrator enables public Sites publishing. The application is prepared for anonymous visitors when that hosting setting becomes available.

## Move-planning refinements

- A clearly labeled synthetic sample walkthrough reveals profile findings before the move plan.
- Section transitions, progressive chart reveals and completion feedback respect reduced-motion preferences.
- Founder wording focuses on deciding to move, preparing the team and building local partnerships.
- Setup, visa questions, bank preparation, pilot shortlists, editable introductions and a first-30-days checklist are saved in My next steps.
- The move-budget scenario adjusts available cash, living allowances and a one-off relocation reserve without modifying extracted company data.
- Saved tasks can be completed, reopened, edited and exported as a text move plan.

A production ecosystem service would need a separate permissions and membership model before processing real founder data.

## Rules and estimates

`lib/rules-matrix.json` contains versioned PRD weights and costs. Official investment criteria, formation fees, visa requirements and directory data are not supplied. All such values are labeled illustrative. Series A and Later have no specified PRD score weights and receive zero pending review. Nothing is sent to external institutions or contacts.

The server build and integration tests are verified. Interactive browser QA and browser WebMCP validation were unavailable in this environment.
