import { z, ZodError } from 'zod';
import { env } from 'cloudflare:workers';
import { blueprint, draft, rules } from '@/lib/rules';
import { initialize, list, get, save, submit, fastTrack, limit, planList, savePlan, planToggle } from '@/lib/store';
import { extract, fromFallback } from '@/lib/extraction';
import { programmeDraft } from '@/lib/programmes';
import { planAction } from '@/lib/move-plan';
export const dynamic='force-dynamic';
function identity(req:Request){
 const user=req.headers.get('oai-authenticated-user-id'),email=req.headers.get('oai-authenticated-user-email');
 if(user&&email)return {owner:user,email,cookie:''};
 const existing=req.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('launchpad_demo='))?.slice(15);
 const valid=existing&&/^[a-f0-9-]{36}$/.test(existing);const id=valid?existing:crypto.randomUUID();
 return {owner:`demo:${id}`,email:'Showcase reviewer',cookie:valid?'':`launchpad_demo=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${new URL(req.url).protocol==='https:'?'; Secure':''}`};
}
const actionInput=z.object({id:z.string().min(1),kind:z.enum(['setup','visa','budget','bank','pilot','intro','settle','programme']),target:z.string().max(120).default(''),role:z.string().max(120).default(''),content:z.string().max(12000).optional(),budget:z.object({cashM:z.number().finite().min(0).max(10000),relocating:z.number().int().min(0).max(10000),relocationUSD:z.number().finite().min(0).max(1e8)}).optional()});
async function handle(req:Request){
 const {owner,email,cookie}=identity(req);
 const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
 try{const path=new URL(req.url).pathname.replace(/^\/api\//,'');
 const config=env as unknown as {OPENAI_API_KEY?:string};
 const admin=true;
 if(req.method==='GET'){
 if(path==='config')return json({aiConfigured:!!config.OPENAI_API_KEY,admin,rulesVersion:rules.version,email});
 if(path==='rules')return json(rules);
 const plan=path.match(/^startups\/([^/]+)\/plan$/);if(plan){if(!await get(owner,plan[1]))return json({error:'Startup not found.'},404);return json({tasks:await planList(owner,plan[1])});}
 await initialize(owner);
 if(path==='admin/pipeline'||path==='startups'){const startups=await list(owner);return json({startups:startups.sort((a,b)=>blueprint(b).score-blueprint(a).score)});}
 const match=path.match(/^(?:admin\/)?startups\/([^/]+)$/);if(match){const s=await get(owner,match[1]);return s?json({startup:s,blueprint:blueprint(s)}):json({error:'Startup not found.'},404);}
 return json({error:'Endpoint not found.'},404);
 }
 if(req.method==='POST'){
 const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'Request origin rejected.'},403);
 if(Number(req.headers.get('content-length')??0)>11*1024*1024)return json({error:'Upload exceeds the 10 MB limit.'},413);
 if(path==='vault/extract'){
 if(await limit(owner))return json({error:'Please wait a minute before another extraction.'},429);
 const body=await req.formData();const files=body.getAll('files').filter((f):f is File=>typeof f!=='string');
 const startup=await extract(files);await save(owner,startup);return json({startup,blueprint:blueprint(startup)},201);
 }
 const payload=await req.json() as any;
 if(path==='plan/actions'){
 const value=actionInput.parse(payload);const s=await get(owner,value.id);if(!s)return json({error:'Startup not found.'},404);
 if(value.kind==='budget'&&((!value.budget&&value.content===undefined)||(value.budget&&value.budget.relocating>s.team)))return json({error:'Check the cash, living allowances and relocation budget.'},400);
 const action=planAction(s,value.kind,value.target,value.role,value.budget);if(value.content!==undefined)action.content=value.content;
 return json({tasks:await savePlan(owner,s.id,value.kind,value.target,action),action},201);
 }
 if(path==='plan/toggle'){const value=z.object({startupId:z.string(),taskId:z.string(),done:z.boolean()}).parse(payload);return json({tasks:await planToggle(owner,value.startupId,value.taskId,value.done)});}

 if(path==='fallback'){const startup=fromFallback(payload);await save(owner,startup);return json({startup,blueprint:blueprint(startup)},201);}
 if(path==='blueprint'){if(typeof payload.id!=='string')return json({error:'Startup id is required.'},400);const s=await get(owner,payload.id);return s?json({startup:s,blueprint:blueprint(s)}):json({error:'Startup not found.'},404);}
 if(path==='drafts'){if(!['adgm','kyc','pilot','outreach','programme'].includes(payload.type))return json({error:'Unknown draft type.'},400);const s=await get(owner,String(payload.id));return s?json({text:payload.type==='programme'?programmeDraft(s,String(payload.target??'')):draft(s,payload.type,String(payload.target??'Abu Dhabi ecosystem partner').slice(0,120),String(payload.role??'partner').slice(0,120))}):json({error:'Startup not found.'},404);}
 const sample=path.match(/^startups\/([^/]+)\/submit$/);if(sample){await initialize(owner);const s=await submit(owner,sample[1]);return s?json({startup:s,blueprint:blueprint(s)}):json({error:'Startup not found.'},404);}
 const issue=path.match(/^admin\/startups\/([^/]+)\/fast-track$/);if(issue){const s=await fastTrack(owner,issue[1],email);return s?json({startup:s,blueprint:blueprint(s)}):json({error:'Startup not found.'},404);}
 return json({error:'Endpoint not found.'},404);
 }
 return json({error:'Method not allowed.'},405);
 }catch(error){console.error('Launchpad request failed',error instanceof Error?error.message:'Unexpected error');const message=error instanceof ZodError?'Please check your company name, sector and funding amount.':error instanceof Error?error.message:'Service unavailable. Please try again.';const status=message.startsWith('Sign in')?401:message.includes('Database')||message.includes('D1')?503:400;return json({error:message.includes('validation')?'Please check your entries.':message},status);}
}
export const GET=handle;export const POST=handle;
