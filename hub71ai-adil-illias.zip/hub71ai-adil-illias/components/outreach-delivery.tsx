'use client';
import {useState} from 'react';
import {Mail} from 'lucide-react';
export function OutreachDelivery({recipient,subject,text}:{recipient:string;subject:string;text:string}){
 const [email,setEmail]=useState('');
 return <form className="outreach-delivery" onSubmit={event=>{event.preventDefault();window.location.href=`mailto:${encodeURIComponent(email.trim())}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`}}><div><strong>Reach out to {recipient}</strong><p>Verify the recipient’s address through your own contact or an official channel. Demo contacts have no supplied email address.</p></div><label htmlFor="outreach-email">Recipient email<input id="outreach-email" type="email" required maxLength={254} placeholder="Enter a verified email address" value={email} onChange={event=>setEmail(event.target.value)}/></label><button className="btn outline" type="submit" disabled={!email.trim()}><Mail size={16}/>Open email draft</button><small>Opens your email app with the message above. Review the recipient and send it yourself.</small></form>
}
