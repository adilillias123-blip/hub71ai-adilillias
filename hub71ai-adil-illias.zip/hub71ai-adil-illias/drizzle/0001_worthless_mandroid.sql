CREATE TABLE `next_steps` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`startup_id` text NOT NULL,
	`kind` text NOT NULL,
	`target` text DEFAULT '' NOT NULL,
	`title` text NOT NULL,
	`section` text NOT NULL,
	`content` text NOT NULL,
	`done` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_next_steps_owner_startup` ON `next_steps` (`owner`,`startup_id`);--> statement-breakpoint
CREATE INDEX `idx_startups_owner` ON `startups` (`owner`);